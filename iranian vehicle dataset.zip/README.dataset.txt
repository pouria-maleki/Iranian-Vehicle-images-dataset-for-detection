# iranian vehicle > 2022-07-28 5:27pm
https://universe.roboflow.com/object-detection/iranian-vehicle-cjfc5

Provided by Roboflow
License: CC BY 4.0

